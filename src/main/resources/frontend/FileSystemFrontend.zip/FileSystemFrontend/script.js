document.addEventListener('DOMContentLoaded', () => {
    const uploadForm = document.getElementById('upload-form');
    const updateForm = document.getElementById('update-form');
    const fileIdInput = document.getElementById('file-id');
    const fileList = document.getElementById('file-list');
    const downloadButton = document.getElementById('download-button');
    const deleteButton = document.getElementById('delete-button');
    const errorPopup = document.getElementById('error-popup');
    const errorMessage = document.getElementById('error-message');

    // Function to show the error popup with a message
    function showErrorPopup(message) {
        errorMessage.textContent = message;
        errorPopup.style.display = 'block';
        setTimeout(() => {
            errorPopup.style.display = 'none';
        }, 5000); // Hide after 5 seconds
    }

    // Function to close the error popup
    function closeErrorPopup() {
        errorPopup.style.display = 'none';
    }

    function clearFileActionSection() {
        fileIdInput.value = '';
        toggleActionButtons(false);
    }


    // Function to fetch and display the file list
    function fetchFileList() {
        fetch('http://localhost:8080/files/list')
            .then(response => {
                if (response.status === 200) {
                    return response.json();
                } else {
                    throw new Error('Error fetching file list');
                }
            })
            .then(data => {
                const fileList = document.getElementById('file-list');
                fileList.innerHTML = ''; // Clear existing list items

                data.forEach(file => {
                    const listItem = document.createElement('li');
                    listItem.setAttribute('data-file-id', file.fileId);
                    listItem.classList.add('file-list-item'); // Add a class for styling
                    listItem.innerHTML = `
                    <span class="file-info"><strong>File Name:</strong> ${file.fileName}</span>
                    <span class="file-info"><strong>Size:</strong> ${file.fileSize} bytes</span>
                    <span class="file-info"><strong>Created At:</strong> ${file.createdAt}</span>
                    <span class="file-info"><strong>File Type:</strong> ${file.contentType}</span>
                    <span class="file-info"><strong>File Id:</strong> ${file.fileId}</span>
                `;
                    fileList.appendChild(listItem);
                });
            })
            .catch(error => {
                console.error('Error fetching file list:', error);
                showErrorPopup('Error fetching file list.');
            });
    }


    // Function to enable/disable action buttons based on selection
    function toggleActionButtons(enabled) {
        downloadButton.disabled = !enabled;
        deleteButton.disabled = !enabled;
    }

    fileList.addEventListener('click', (event) => {
        const listItem = event.target.closest('li'); // Find the closest <li> element
        if (listItem) {
            const selectedFileId = listItem.getAttribute('data-file-id');
            toggleActionButtons(selectedFileId !== null);
            fileIdInput.value = selectedFileId !== null ? selectedFileId : '';

            // Change the background color of the selected item
            const listItems = fileList.getElementsByTagName('li');
            for (const item of listItems) {
                item.style.backgroundColor = '';
            }
            listItem.style.backgroundColor = '#e0f0ff'; // Highlight the clicked item
        }
    });

    // Event listener for file input change
    const fileInput = document.getElementById('file-input');
    fileInput.addEventListener('change', () => {
        // Populate file name and metadata when a file is selected
        const selectedFile = fileInput.files[0];
        const metadataInput = document.getElementById('metadata');
        const fileNameInput = document.getElementById('file-name');
        if (selectedFile) {
            // Populate file name input
            fileNameInput.value = selectedFile.name;

            // Populate metadata input with fileType, size, lastModified, and createdTime
            const fileType = selectedFile.type;
            const size = selectedFile.size;
            const createdTime = new Date(selectedFile.lastModified).toLocaleString();

            const metadata = {
                fileType: fileType,
                size: `${size} bytes`,
                createdTime: createdTime
            };

            // Construct the metadata string
            const metadataString = JSON.stringify(metadata);
            metadataInput.value = metadataString;
        } else {
            // Clear the fields if no file is selected
            fileNameInput.value = '';
            metadataInput.value = '';
        }
    });

    const updateFileInput = document.getElementById('updated-file-input');
    updateFileInput.addEventListener('change', () => {
        // Populate file name and metadata when a file is selected
        const selectedFile = updateFileInput.files[0];
        const metadataInput = document.getElementById('updated-metadata');
        const fileNameInput = document.getElementById('updated-file-name');
        if (selectedFile) {
            // Populate file name input
            fileNameInput.value = selectedFile.name;

            // Populate metadata input with fileType, size, lastModified, and createdTime
            const fileType = selectedFile.type;
            const size = selectedFile.size;
            const createdTime = new Date(selectedFile.lastModified).toLocaleString();


            const metadata = {
                fleType: fileType,
                size: `${size} bytes`,
                createdTime: createdTime,
            };

            // Construct the metadata string
            const metadataString = JSON.stringify(metadata);
            metadataInput.value = metadataString;
        } else {
            // Clear the fields if no file is selected
            fileNameInput.value = '';
            metadataInput.value = '';
        }
    });


    // Event listener for input field changes
    fileIdInput.addEventListener('input', () => {
        // Remove disabled state from action buttons when input field is not empty
        toggleActionButtons(fileIdInput.value !== '');
    });

    // Event listener for form submission (file upload)
    uploadForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const formData = new FormData(uploadForm);

        fetch('http://localhost:8080/files/upload', {
                method: 'POST',
                body: formData,
            })
            .then(response => {
                if (response.status === 200) {
                    // File uploaded successfully, refresh file list
                    fetchFileList();
                    uploadForm.reset();
                } else {
                    console.error('Error uploading file:', response.statusText);
                    showErrorPopup('Error uploading file.');
                }
            })
            .catch(error => {
                console.error('Error uploading file:', error);
                showErrorPopup('Error uploading file.');
            });
    });



    // Event listener for download button
    downloadButton.addEventListener('click', () => {
        const selectedFileId = fileIdInput.value;
        if (selectedFileId) {
            // Trigger file download using the file's fileId
            window.location.href = `http://localhost:8080/files/${selectedFileId}`;
            clearFileActionSection();
        } else {
            showErrorPopup('Please select a file to download.');
        }
    });




    updateForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const selectedFileId = fileIdInput.value; // Get the selected file ID
        const formData = new FormData(updateForm);

        // Construct the API URL with the selected file ID
        const apiUrl = `http://localhost:8080/files/update/${selectedFileId}`;

        fetch(apiUrl, {
                method: 'PUT',
                body: formData,
            })
            .then(response => {
                if (response.status === 200) {
                    // Metadata updated successfully, refresh file list
                    fetchFileList();
                    updateForm.reset();
                } else {
                    console.error('Error updating metadata:', response.statusText);
                    showErrorPopup('Error updating metadata.');
                }
            })
            .catch(error => {
                console.error('Error updating metadata:', error);
                showErrorPopup('Error updating metadata.');
            });
    });

    // Event listener for delete button
    deleteButton.addEventListener('click', () => {
        const selectedFileId = fileIdInput.value;
        if (selectedFileId) {
            fetch(`http://localhost:8080/files/${selectedFileId}`, {
                    method: 'DELETE',
                })
                .then(response => {
                    if (response.status === 200) {
                        // File deleted successfully, refresh file list
                        fetchFileList();
                        toggleActionButtons(false);
                        clearFileActionSection();
                    } else {
                        console.error('Error deleting file:', response.statusText);
                        showErrorPopup('Error deleting file.');
                    }
                })
                .catch(error => {
                    console.error('Error deleting file:', error);
                    showErrorPopup('Error deleting file.');
                });
        } else {
            showErrorPopup('Please select a file to delete.');
        }
    });

    // Initial fetch of the file list
    fetchFileList();
});